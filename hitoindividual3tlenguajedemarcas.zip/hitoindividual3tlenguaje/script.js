const display = document.querySelector('.input');
const clearBtn = document.querySelector('.clear');
const percentBtn = document.querySelector('.percent');
const squareBtn = document.querySelector('.square');
const sqrtBtn = document.querySelector('.sqrt');
const numberBtns = document.querySelectorAll('.number');
const operatorBtns = document.querySelectorAll('.operator');
const equalsBtn = document.querySelector('.equals');

let firstOperand = null;
let operator = null;
let secondOperand = null;

function clear() {
  display.textContent = '';
  firstOperand = null;
  operator = null;
  secondOperand = null;
}

function calculate() {
  let result;
  const operand1 = parseFloat(firstOperand);
  const operand2 = parseFloat(secondOperand);

  switch (operator) {
    case '+':
      result = operand1 + operand2;
      break;
    case '-':
      result = operand1 - operand2;
      break;
    case '*':
      result = operand1 * operand2;
      break;
    case '/':
      result = operand1 / operand2;
      break;
    case '%':
      result = operand1 % operand2;
      break;
    default:
      return;
  }

  clear();
  display.textContent = result;
}

function handleNumberClick(event) {
  const number = event.target.value;
  display.textContent += number;
}

function handleOperatorClick(event) {
  const operatorClicked = event.target.value;
  if (operator) {
    secondOperand = display.textContent;
    calculate();
    firstOperand = display.textContent;
  } else {
    firstOperand = display.textContent;
  }
  operator = operatorClicked;
  display.textContent = '';
}

function handleEqualsClick() {
  secondOperand = display.textContent;
  calculate();
}

function handlePercentClick() {
  firstOperand = display.textContent;
  operator = '%';
  calculate();
}

function handleSquareClick() {
  firstOperand = display.textContent;
  const operand = parseFloat(firstOperand);
  const result = operand * operand;
  clear();
  display.textContent = result;
}

function handleSqrtClick() {
  firstOperand = display.textContent;
  const operand = parseFloat(firstOperand);
  const result = Math.sqrt(operand);
  clear();
  display.textContent = result;
}

clearBtn.addEventListener('click', clear);
numberBtns.forEach(button => button.addEventListener('click', handleNumberClick));
operatorBtns.forEach(button => button.addEventListener('click', handleOperatorClick));
equalsBtn.addEventListener('click', handleEqualsClick);
percentBtn.addEventListener('click', handlePercentClick);
squareBtn.addEventListener('click', handleSquareClick);
sqrtBtn.addEventListener('click', handleSqrtClick);
